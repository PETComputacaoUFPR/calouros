#s pastas
#dentro delas vão ter diferentes tipos de diretórios
#os remova-me precisam ser deletados
#os mova-me precisam ser movido para a pasta resultado
#os copie-me precisam ser copiados para a pasta resultado e serem apagados depois
#concatenar todos os arquivos de texto dentro de um arquivo na pasta resultado usando cat e >>
#dar o comando cat no arquivo de texto

mkdir A\ queda\ na\ toca\ do\ Coelho\ Branco
	touch A\ queda\ na\ toca\ do\ Coelho\ Branco/mova-me3
	echo "Aos membros do PET é oferecida uma bolsa de R\$400.00 (quatrocentos reais), uma forma de estímulo e auxílio para que possam se dedicar aos projetos do PET. A carga horária é de 20 (vinte) horas semanais." > A\ queda\ na\ toca\ do\ Coelho\ Branco/mova-me3
	touch A\ queda\ na\ toca\ do\ Coelho\ Branco/remova-me43
	touch A\ queda\ na\ toca\ do\ Coelho\ Branco/remova-me23
	touch A\ queda\ na\ toca\ do\ Coelho\ Branco/remova-me75

mkdir A\ Lagoa\ de\ Lágrimas
	touch A\ Lagoa\ de\ Lágrimas/mova-me1
	echo "O PET Computação consiste em um grupo de graduandos em Ciência da Computação e Informática Biomédica interessados em ampliar o conhecimento além do que é oferecido pelos cursos oferecidos pelo Departamento de Informática." > A\ Lagoa\ de\ Lágrimas/mova-me1
	touch A\ Lagoa\ de\ Lágrimas/rem0va-me45
	touch A\ Lagoa\ de\ Lágrimas/remova-me3634
	touch A\ Lagoa\ de\ Lágrimas/remova-me738
	touch A\ Lagoa\ de\ Lágrimas/r3mova-me4

mkdir Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/copie-me2
    echo "Durante o ano de 2022, os jovens poderão efetuar o seu alistamento pela internet, acessando o site web.inf.ufpr.br/pet " > Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/copie-me2
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/remova-me345
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/remova-me53
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/Remov@-me4334
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/remova-me312
	touch Uma\ Corrida\ de\ comitê\ e\ Uma\ Historia\ comprida/remova-me123

mkdir O\ Coelho\ da\ um\ encargo\ a\ Bill
	touch O\ Coelho\ da\ um\ encargo\ a\ Bill/mova-me4
	echo "Como membros do PET Computação, acreditamos em auxiliar os alunos em sua gradução e sua formação global, tanto de nós, bolsistas, quanto de nossos colegas do curso. Acreditamos na importância da participação ativa do PET na parte administativa do curso, protegendo os interesses da classe estudantil. E, por fim, acreditamos na importância de nos manter verdadeiros aos objetivos do Programa de Educação Tutorial nas sua formação de alunos capazes e interessados em expandir seu conhecimento pessoal com iniciativa." > O\ Coelho\ da\ um\ encargo\ a\ Bill/mova-me4
	touch O\ Coelho\ da\ um\ encargo\ a\ Bill/copie-me3
    echo "Também deverão consultar o mesmo site, para saber se prosseguirão no processo seletivo para o PET Computação." > O\ Coelho\ da\ um\ encargo\ a\ Bill/copie-me3
	touch O\ Coelho\ da\ um\ encargo\ a\ Bill/53mova-m3
	touch O\ Coelho\ da\ um\ encargo\ a\ Bill/remova-me42

mkdir Conselhos\ de\ uma\ Lagarta
	touch Conselhos\ de\ uma\ Lagarta/remova-me343
	touch Conselhos\ de\ uma\ Lagarta/remova-me54532
	touch Conselhos\ de\ uma\ Lagarta/remova-me12
	touch Conselhos\ de\ uma\ Lagarta/remova-me536
	touch Conselhos\ de\ uma\ Lagarta/remova-me1213
	touch Conselhos\ de\ uma\ Lagarta/.ajude-me

mkdir Porco\ e\ Pimenta
	touch Porco\ e\ Pimenta/remove-me
	touch Porco\ e\ Pimenta/remova-me3
	touch Porco\ e\ Pimenta/remova-me4564
	touch Porco\ e\ Pimenta/remova-me9876
	touch Porco\ e\ Pimenta/remova-me6
	touch Porco\ e\ Pimenta/remova-me68
	touch Porco\ e\ Pimenta/remova-me777

mkdir Um\ chá\ de\ loucos
	touch Um\ chá\ de\ loucos/mova-me2
	echo "O Programa oferece condições para a realização de atividades extracurriculares. Sob a orientação de um tutor, os membros do PET se mobilizam em diversos projetos que englobam diversas áreas do curso de Ciência da Computação e do curso de Informática Biomédica, com o objetivo de gerar pessoas não apenas com uma vasta gama de conhecimentos, como estimular o pensamento crítico e o desenvolvimento de habilidades para resolução de problemas, preparando tanto para o mercado profissional como para o desenvolvimento acadêmico." > Um\ chá\ de\ loucos/mova-me2
	touch Um\ chá\ de\ loucos/remova\ me
	touch Um\ chá\ de\ loucos/r3m0va\=me
	touch Um\ chá\ de\ loucos/remova-346me
	touch Um\ chá\ de\ loucos/remova-me123
	touch Um\ chá\ de\ loucos/remova-me57
	touch Um\ chá\ de\ loucos/rem234ova-me
	touch Um\ chá\ de\ loucos/remova-me64

mkdir O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas
	touch O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas/copie-me1
    echo "O PET Computação estará promovendo o Alistamento Petiano Online. A iniciativa permite ao jovem brasileiro, realizar o seu alistamento Petiano “online”, utilizando os recursos da tecnologia da informação e da rede mundial de computadores. " > O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas/copie-me1
	touch O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas/removaa-me
	touch O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas/rremova-me
	touch O\ Campo\ de\ Croqué\ da\ Rainha\ de\ Copas/rem00ooova-me

mkdir A\ História\ da\ Tartaruga\ Falsa
	touch A\ História\ da\ Tartaruga\ Falsa/r3mov3-m3
	touch A\ História\ da\ Tartaruga\ Falsa/removasd-me
	touch A\ História\ da\ Tartaruga\ Falsa/rmeova-me
	touch A\ História\ da\ Tartaruga\ Falsa/remova-me23
	touch A\ História\ da\ Tartaruga\ Falsa/remova-m132e
	touch A\ História\ da\ Tartaruga\ Falsa/remova-m869e

mkdir A\ Quadrilha\ da\ lagosta
	touch A\ Quadrilha\ da\ lagosta/copie-me4
    echo "Todos estão convidados para fazer parte da grande FAMILIA que é o PET Computação, não se esqueçam! Sigam a página no Facebook e nosso Instagram @petcompufpr para saber quando as inscrições serão abertas! Abraços à todos!!!!!" > A\ Quadrilha\ da\ lagosta/copie-me4
	touch A\ Quadrilha\ da\ lagosta/remova-me
	touch A\ Quadrilha\ da\ lagosta/em-avomer

mkdir Quem\ Roubou\ as\ Tortas?
	touch Quem\ Roubou\ as\ Tortas?/remova-mepls
	touch Quem\ Roubou\ as\ Tortas?/remova-me\?
	touch Quem\ Roubou\ as\ Tortas?/rreemmoovvaa--mmee

mkdir O\ Depoimento\ de\ Alice
touch O\ Depoimento\ de\ Alice/depoimento.txt

